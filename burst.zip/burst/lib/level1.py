#!/usr/local/lib/python2.7
########################################################################
# Copyright (C) 2017 SERCO SpA                                         #   
# Giovanna Palumbo giovanna.palumbo@serco.com                          #
#                                                                      #
########################################################################
import os
import xml.etree.ElementTree
import datetime
import pprint
import numpy

class SLC(object):
    def __init__(self,safeFolder):
        self.slcProduct=safeFolder
        self.listfilenameProduct=dict()
        self.listSLCFolder(self.slcProduct)
        #pprint.pprint(self.listfilenameProduct)
        self.namespace={'s1sarl2'   :"http://www.esa.int/safe/sentinel-1.0/sentinel-1/sar/level-2",\
                        'safe'      :"http://www.esa.int/safe/sentinel-1.0",\
                        's1'        :"http://www.esa.int/safe/sentinel-1.0/sentinel-1",\
                        's1sar'     :"http://www.esa.int/safe/sentinel-1.0/sentinel-1/sar" ,\
                        's1sarl1'   :"http://www.esa.int/safe/sentinel-1.0/sentinel-1/sar/level-1" 
                         }
        self.pol=["coPol","crossPol"]
        self.listManifest=dict()
        self.parseManifest()
        self.listAnnotation=dict()
        self.parseAnnotation()
        self.listCalibration=dict()
        self.blockInfofromLastRaw=dict()
        self.blockInfo=dict()
        
    def  listSLCFolder(self,slcProduct) :
        tmpdir=os.path.dirname(slcProduct)
        
        extension = os.path.splitext(slcProduct)[1]
        self.listfilenameProduct['SLCfilename']=os.path.splitext(slcProduct)[0]
        if extension=='.SAFE':
            self.listfilenameProduct['crossPol']=dict()
            self.listfilenameProduct['coPol']=dict()
            self.listfilenameProduct['crossPol']['annotationFilename']=dict()
            self.listfilenameProduct['coPol']['annotationFilename']=dict()

            self.listfilenameProduct['crossPol']['calibrationFilename']=dict()
            self.listfilenameProduct['coPol']['calibrationFilename']=dict()

            self.listfilenameProduct['crossPol']['noiseFilename']=dict()
            self.listfilenameProduct['coPol']['noiseFilename']=dict()

            self.listfilenameProduct['crossPol']['tiffFilename']=dict()
            self.listfilenameProduct['coPol']['tiffFilename']=dict()
            for dirname, dirnames, filenames in os.walk(slcProduct,followlinks=True):

                for file in filenames:

                    if file.endswith('quick-look.png'):
                        self.listfilenameProduct['quickLookFilename']=dirname+'/quick-look.png'
                    if file.endswith('manifest.safe'):
                        self.listfilenameProduct['manifestFilename']= dirname+'/manifest.safe'
 
                    if os.path.basename(dirname)=='annotation' and file.startswith('s1') and file.endswith('.xml'):
                        swath=file[6:7]
                        if 'vh' in file or 'hv' in file:
                            self.listfilenameProduct['crossPol']['annotationFilename'][swath]=dirname+'/'+file                            
                        elif 'hh' in file or 'vv' in file:   
                            self.listfilenameProduct['coPol']['annotationFilename'][swath]=dirname+'/'+file

                        
                    if os.path.basename(dirname)=='calibration'  and file.endswith('.xml'):
                        for mode in ['calibration', 'noise']:
                            if file.startswith('calibration'):
                                swath=file[18:19]
                            elif file.startswith('noise') :
                                swath=file[12:13]
                            if ('vh' in file or 'hv'  in file) and file.startswith(mode):
                                self.listfilenameProduct['crossPol'][mode+'Filename'][swath]=dirname+'/'+file              
                            elif ('hh' in file or 'vv' in file) and file.startswith(mode):   
                                self.listfilenameProduct['coPol'][mode+'Filename'][swath]=dirname+'/'+file 
  
                    if os.path.basename(dirname)=='measurement' and file.startswith('s1') and file.endswith('.tiff'):
                        swath=file[6:7]
                        if 'vh' in file or 'hv' in file:
                            self.listfilenameProduct['crossPol']['tiffFilename'][swath]=dirname+'/'+file
                        elif 'hh' in file or 'vv' in file:   
                            self.listfilenameProduct['coPol']['tiffFilename'][swath]=dirname+'/'+file 
        return

    def parseManifest(self):
        filenameManifest=self.listfilenameProduct['manifestFilename']
        self.treeManifestProduct=xml.etree.ElementTree.parse(filenameManifest)
        self.listManifest['mode']=self.treeManifestProduct.find('.//metadataWrap/xmlData/safe:platform/safe:instrument/safe:extension/s1sarl1:instrumentMode/s1sarl1:mode',self.namespace).text
        self.listManifest['numberOfSwath']=len(self.treeManifestProduct.findall('.//metadataWrap/xmlData/safe:platform/safe:instrument/safe:extension/s1sarl1:instrumentMode/s1sarl1:swath',self.namespace))
        self.listManifest['numberOfPolarization']=len(self.treeManifestProduct.findall('.//metadataWrap/xmlData/s1sarl1:standAloneProductInformation/s1sarl1:transmitterReceiverPolarisation',self.namespace))
        #print self.listManifest

    def parseAnnotation(self):
        for ipol in range(self.listManifest['numberOfPolarization']):
            self.listAnnotation[self.pol[ipol]]=dict()
            for iswath in range(1,self.listManifest['numberOfSwath']+1):
                self.treeAnnotation=xml.etree.ElementTree.parse(self.listfilenameProduct[self.pol[ipol]]['annotationFilename'][str(int(iswath))])
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]=dict()
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['swath']=self.treeAnnotation.find('.//adsHeader/swath').text               
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['productFirstLineUtcTime']=datetime.datetime.strptime(self.treeAnnotation.find('.//imageAnnotation/imageInformation/productFirstLineUtcTime',self.namespace).text,"%Y-%m-%dT%H:%M:%S.%f")
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['productLastLineUtcTime']=datetime.datetime.strptime(self.treeAnnotation.find('.//imageAnnotation/imageInformation/productLastLineUtcTime',self.namespace).text,"%Y-%m-%dT%H:%M:%S.%f")
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['azimuthTimeInterval']=self.treeAnnotation.find('.//imageAnnotation/imageInformation/azimuthTimeInterval',self.namespace).text
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['numberOfSamples']=self.treeAnnotation.find('.//imageAnnotation/imageInformation/numberOfSamples',self.namespace).text
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['numberOfLines']=self.treeAnnotation.find('.//imageAnnotation/imageInformation/numberOfLines',self.namespace).text
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['numberOfburst']=int(self.treeAnnotation.find('.//swathTiming/burstList',self.namespace).get('count'))
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['samplesPerBurst']=self.treeAnnotation.find('.//swathTiming/samplesPerBurst',self.namespace).text
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['linesPerBurst']=self.treeAnnotation.find('.//swathTiming/linesPerBurst',self.namespace).text               
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['infoBurst']=dict()
                for iburst in range(1,self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['numberOfburst']+1):
                    self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['infoBurst'][iburst]=dict()
                    self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['infoBurst'][iburst]['azimuthTime']=datetime.datetime.strptime(self.treeAnnotation.find('//swathTiming/burstList/burst['+str(iburst)+']/azimuthTime',self.namespace).text,"%Y-%m-%dT%H:%M:%S.%f")

                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['geolocationGrid']=dict()
                self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['geolocationGrid']['count']=int(self.treeAnnotation.find('.//geolocationGrid/geolocationGridPointList',self.namespace).get('count'))
                for igeolocationGrid in range(1,self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['geolocationGrid']['count']+1):
                    self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['geolocationGrid'][igeolocationGrid]=dict()
                    self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['geolocationGrid'][igeolocationGrid]['azimuthTime']=datetime.datetime.strptime(self.treeAnnotation.find('.//geolocationGrid/geolocationGridPointList/geolocationGridPoint['+str(igeolocationGrid)+']/azimuthTime',self.namespace).text,"%Y-%m-%dT%H:%M:%S.%f")
                    self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['geolocationGrid'][igeolocationGrid]['line']=int(self.treeAnnotation.find('.//geolocationGrid/geolocationGridPointList/geolocationGridPoint['+str(igeolocationGrid)+']/line',self.namespace).text)
                    #self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['geolocationGrid'][igeolocationGrid]['pixel']=int(self.treeAnnotation.find('.//geolocationGrid/geolocationGridPointList/geolocationGridPoint['+str(igeolocationGrid)+']/pixel',self.namespace).text)
                    #self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['geolocationGrid'][igeolocationGrid]['latitude']=(self.treeAnnotation.find('.//geolocationGrid/geolocationGridPointList/geolocationGridPoint['+str(igeolocationGrid)+']/latitude',self.namespace).text)
                    #self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['geolocationGrid'][igeolocationGrid]['longitude']=(self.treeAnnotation.find('.//geolocationGrid/geolocationGridPointList/geolocationGridPoint['+str(igeolocationGrid)+']/longitude',self.namespace).text)
                    
                #pprint.pprint(self.listAnnotation[self.pol[ipol]]['swath_'+str(iswath)]['geolocationGrid'])

       



