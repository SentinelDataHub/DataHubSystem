#!/usr/local/lib/python2.7
########################################################################
# Copyright (C) 2017 SERCO SpA                                         #
# Giovanna Palumbo giovanna.palumbo@serco.com                          #
#                                                                      #
########################################################################
import level1
import os
import commands
import hashlib
import datetime
import sys
import config
import time

prjName='burst'
currDir=os.path.dirname(os.path.abspath(__file__))
pathFrameworkGDAL=config.ini.get('main','pathFrameworkGDAL')
print pathFrameworkGDAL
prjFolder=currDir.split(prjName)[0]+prjName

config=prjFolder+'/config/'
manifestTemplate=config+'/manifest.xml'
class getBurst(object):
    def __init__(self,slcSafe):
        self.slcfile=slcSafe
        self.outputBurst=self.slcfile +'/burst'
        if not os.path.exists(self.outputBurst):
            os.mkdir(self.outputBurst)
        self.slc=level1.SLC(self.slcfile)
    
    
    def getBurst(self):
        for ipol in range(self.slc.listManifest['numberOfPolarization']):
            for iswath in range(1,self.slc.listManifest['numberOfSwath']+1):
                #For each swath and for each polarization get :
                #the correspondent tiffProduct
                #From the correspondent annotation file get the number of burst, linesPerBurst and NumberOfSamples .
                pol=self.slc.pol[ipol]
                tiffProduct=self.slc.listfilenameProduct[pol]['tiffFilename'][str(iswath)]
                linesPerBurst=int(self.slc.listAnnotation[pol]['swath_'+str(iswath)]['linesPerBurst'])
                numberOfSamples=self.slc.listAnnotation[pol]['swath_'+str(iswath)]['numberOfSamples']
                azimuthTimeInterval=self.slc.listAnnotation[pol]['swath_'+str(iswath)]['azimuthTimeInterval']
                for iburst in range(1,self.slc.listAnnotation[pol]['swath_'+str(iswath)]['numberOfburst']+1):
                    #For each burst  get the startTimeBurst(azimuthTime)
                    
                    getInfoBurst=dict()
                    getInfoBurst['numberSwath']=str(iswath)
                    getInfoBurst['numberBurst']=str(iburst)
                    getInfoBurst['filenameSLC']=self.slc.listfilenameProduct['SLCfilename']
                    getInfoBurst['startTimeBurst']=self.slc.listAnnotation[pol]['swath_'+str(iswath)]['infoBurst'][iburst]['azimuthTime']
                    ##From the geolocationGrid extract the line (startLineBurst) correspondent to the startTimeBurst (convertion [azimuthTime to line] using the GeolocatedGrid )
                    for igeolocationGrid in range(1,self.slc.listAnnotation[pol]['swath_'+str(iswath)]['geolocationGrid']['count']):
                        if getInfoBurst['startTimeBurst']>=self.slc.listAnnotation[pol]['swath_'+str(iswath)]['geolocationGrid'][igeolocationGrid]['azimuthTime']and \
                        getInfoBurst['startTimeBurst']<self.slc.listAnnotation[pol]['swath_'+str(iswath)]['geolocationGrid'][igeolocationGrid+1]['azimuthTime']:
                            startLineBurst=self.slc.listAnnotation[pol]['swath_'+str(iswath)]['geolocationGrid'][igeolocationGrid]['line']
                    #build the stopLineBurst.
                    stopLineBurst=startLineBurst+linesPerBurst
                    #C0 and C1 are the first sample and the last sample
                    c0=1
                    c1=int(numberOfSamples)-1
                    getInfoBurst['outputFilename']=self.outputBurst+'/Burst_'+pol+'_'+str(iswath)+'_'+str(iburst)+'.tiff'
                    
                    minx = c0
                    maxy = startLineBurst
                    maxx =c1
                    miny = stopLineBurst
                    #Cut the tiffProduct whit startLineBurst,stopLineBurst,C0 , C1
                    cmd1=pathFrameworkGDAL+'gdal_translate -projwin ' + ' '.join([str(x) for x in [minx, maxy, maxx, miny]]) + ' -of GTiff '+tiffProduct +' '+getInfoBurst['outputFilename']
                    os.system(cmd1)
                    cmd2=pathFrameworkGDAL+'gdalinfo ' + getInfoBurst['outputFilename']+'|grep -i TIFFTAG_IMAGEDESCRIPTION'
                    
                    TIFFTAG_IMAGEDESCRIPTION= (commands.getstatusoutput(cmd2)[1]).replace('TIFFTAG_IMAGEDESCRIPTION=','')
                    newTIFFTAG_IMAGEDESCRIPTION="'"+TIFFTAG_IMAGEDESCRIPTION+'swath='+str(iswath)+' burst='+str(iburst)+"'"
                    cmd3=pathFrameworkGDAL+'gdal_edit.py -mo TIFFTAG_IMAGEDESCRIPTION='+newTIFFTAG_IMAGEDESCRIPTION+' '+getInfoBurst['outputFilename']
                    os.system(cmd3)
                    #create a manifest.safe
                    self.createManifest(getInfoBurst)



def createManifest(self,infoBurst):
    self.replacements =dict()
        
        self.replacements ['_version_']          ='0.0.0'
        self.replacements ['_timeprocessing_']   =str((datetime.datetime.now()))
        self.replacements ['_filenameSLC_']      =infoBurst['filenameSLC']
        self.replacements ['_numberSwath_']      =infoBurst['numberSwath']
        self.replacements ['_numberBurst_']      =infoBurst['numberBurst']
        self.replacements ['_startTimeBurst_']   =str(infoBurst['startTimeBurst'].strftime("%Y-%m-%dt%H:%M:%S"))
        self.replacements ['_cornerUpLeft_']     =''#str(infoBurst['cornerUpLeft'])
        self.replacements ['_cornerDownLeft_']   =''#str (infoBurst['cornerDownLeft'])
        self.replacements ['_cornerUpRigth_']    =''#str(  infoBurst['cornerUpRigth'] )
        self.replacements ['_cornerDownRigth_']  =''#str( infoBurst['cornerDownRigth'] )
        self.replacements ['_filenameBurst_']    =infoBurst['outputFilename']
        self.replacements ['_sizefilenameBurst_']=str(os.path.getsize(infoBurst['outputFilename']))
        self.replacements ['_md5_']              =hashlib.md5(open(infoBurst['outputFilename'], 'rb').read()).hexdigest()
        
        infile=open(manifestTemplate,'r')
        filenameManifest=infoBurst['outputFilename'].replace('.tiff','_manifest.xml')
        outfile=open(filenameManifest, 'w')
        for line in infile:
            for src, target in self.replacements.iteritems():
                line = line.replace(src, target)
            outfile.write(line)

def go(path):
    excst= time.time()
    slc=getBurst(path)
    slc.getBurst()
    try:
        exitCode=0
    except:
        print("General exception")
        exitCode=1
    excen= time.time()
    print("Run completed in %s seconds:", excen-excst)
    sys.exit(exitCode)

go(sys.argv[1])